package com.example.feedthekitty

data class User(
    val name : String = "",
    val balance: String = "1000.00",
    val tabs: String = "",
    val ownedTabs: String  = ""
)